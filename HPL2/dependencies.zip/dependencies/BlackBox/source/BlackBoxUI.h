//BlackBoxUI.h

#ifndef _BLACKBOXUI_H__
#define _BLACKBOXUI_H__


extern const char* g_errorLable;

extern const char* g_mailToAddress;

extern const char* g_submitBugURL;

int ShowBlackBoxUI( EXCEPTION_POINTERS * pExPtrs, HINSTANCE hInstance );

#endif //_BLACKBOXUI_H__